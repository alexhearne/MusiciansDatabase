<html>
<body>
 <form action = 'insert.php' method = 'post'>
Venue Name:
 <input type = "text" name="Venue Name" id = venueName>
Year Established:
 <input type = "text" name = "Venue Established" id =venueEstablished>
Type of Venue:
 <input type ="text" name = "Type of Venue" id = venueType>
Venue Address:
 <input type ="text" name = "Venue Address" id = venueAddress>

</form>
</body>
</html>