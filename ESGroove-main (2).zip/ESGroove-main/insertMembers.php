<html>
<body>
 <form action = 'insert.php' method = 'post'>
Member Name:
 <input type = "text" name="Member Name" id = memberName>
Instrument Name:
 <input type = "text" name = "Instrument Name" id =instrumentName>
Band Name:
 <input type ="text" name = "Band Name" id = bandNameMem>

</form>
</body>
</html>