# 386Project
### Contributors:
Dylan McDonald dylmcd13@gmail.com
Braiden Ryan braidenjester@gmail.com
Cole Nussear c.nussear@gmail.com
Alex Hearne alexhearne84@gmail.com

Update Page:
https://lamp.salisbury.edu/~dmcdonald2/updateTableHome.php



Weekly assignments:

11/5 - 11/12
Alex: Username and Password admin login page
Dylan: Page for adding stuff to tables 
Braiden: Page for deleting stuff from tables
Ryan: Page for updating stuff from tables
Cole: Admin login page

