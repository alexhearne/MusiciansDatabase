<html>
<body>
 <form action = 'insert.php' method = 'post'>
 <form action = 'insert.css' method = 'post'>


<html>
<head>
 <meta charset="utf-8">
 <title> Insert List</title>
 <link rel="stylesheet" type="text/css" href="insert.css">
</head>
<body>

<ul>
 <li><a href="#">Home</a></li>
 <li><a href="#">Music</a>
  <ul>
   <li><a href="insertBands.php">Bands</a></li>
   <li><a href="insertVenues.php">Venues</a></li>
   <li><a href="insertSongs.php">Songs</a></li>
   <li><a href="insertAlbum.php">Album</a></li>
   <li><a href="insertMembers.php">Members</a></li>
  </ul>


 <li><a href="#">Social Media</a>
  <ul>
   <li><a href="insertTwitter.php">Twitter</a></li>
   <li><a href="insertFacebook.php">Facebook</a></li>
   <li><a href="insertInstagram.php">Instagram</a></li>
  </ul>

 </li>

 <li><a href="#">Others</a>
  <ul>
   <li><a href="insertUsers.php">Users</a></li>


</ul>
</body>
</html>