<html>
<body>
        <form action = 'insert.php' method ='post'>
Band Name:
<input type = 'text' name = 'Band Name' id = bandName>
Bands Genre:
<input type = 'text' name = 'Band Genre' id = bandGenre>
Number of Members:
<input type = 'text' name = 'Number of Members' id = numMembers>
Number of Years Active:
<input type = 'text' name = 'Number of Years Active' id = numYearsActive>

</form>
</body>
</html>