<html>
<body>
 <form action = 'insert.php' method = 'post'>
Song Title:
 <input type = "text" name="Song Title" id = songTitle>
Album of Song:
 <input type = "text" name = "Name of Album" id =albumTitle>
Band Name:
 <input type ="text" name = "Band Name" id = nameOfBand>
Song Length:
 <input type ="text" name = "Song Length" id = songLength>

</form>
</body>
</html>