<html>
<body>
 <form action = 'insert.php' method = 'post'>
Album Title:
 <input type = "text" name="Album Title" id = albumTitle>
Band Name:
 <input type = "text" name = "Band Name" id =bandName>
Number of Tracks:
 <input type ="text" name = "Number of Tracks" id = numOfTracks>
Album Length:
 <input type ="text" name = "Album Length" id = albumLegnth>
Release Year of Album:
 <input type = "text" name = "Release Year" id = releaseYear>

</form>
</body>
</html>